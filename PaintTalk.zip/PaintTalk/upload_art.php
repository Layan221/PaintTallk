<?php
// upload_art.php
session_start();
require 'db.php';
if (!isset($_SESSION['user'])) { header('Location: login.php'); exit; }

$msg = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $title = trim($_POST['title'] ?? '');
    $desc  = trim($_POST['desc'] ?? '');

    if (isset($_FILES['image']) && $_FILES['image']['error']===UPLOAD_ERR_OK) {
        $okTypes = ['image/jpeg','image/png','image/webp','image/gif'];
        if (!in_array($_FILES['image']['type'], $okTypes)) {
            $msg = 'صيغة الصورة غير مدعومة.'; 
        } else {
            if (!is_dir('uploads')) mkdir('uploads');
            $ext  = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $name = 'uploads/'.time().'_'.mt_rand(1000,9999).'.'.$ext;
            move_uploaded_file($_FILES['image']['tmp_name'], $name);

            $ins = $pdo->prepare("INSERT INTO artworks (user_id,title,description,image_path) VALUES (?,?,?,?)");
            $ins->execute([$_SESSION['user']['id'], $title, $desc, $name]);
            header('Location: index.php'); exit;
        }
    } else {
        $msg = 'اختاري صورة.';
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<title>رفع رسمة | PaintTalk</title>
<style>
:root{ --bg:#F7F3ED; --brand:#7B1E3A; --brand-d:#5f152d; }
body{margin:0;background:var(--bg);font-family:"Tajawal",Arial}
.header{display:flex;justify-content:space-between;align-items:center;padding:14px 18px;border-bottom:1px solid #e9e4dd;background:var(--bg)}
.btn{background:var(--brand);color:#fff;border:none;border-radius:10px;padding:8px 14px;cursor:pointer;font-weight:600}
.btn:hover{background:var(--brand-d)}
.container{max-width:700px;margin:28px auto;padding:0 16px}
form{background:#fff;border-radius:14px;padding:20px;box-shadow:0 6px 18px rgba(0,0,0,.06)}
label{display:block;margin:10px 4px 6px;font-weight:700}
input[type="text"],textarea,input[type="file"]{width:100%;padding:10px;border:1px solid #ccc;border-radius:8px}
textarea{min-height:90px}
.submit{margin-top:14px}
.msg{color:#b00020;margin-top:10px}
</style>
</head>
<body>
<header class="header">
  <div>
    <a class="btn" href="index.php">المعرض</a>
    <a class="btn" href="logout.php">تسجيل الخروج</a>
  </div>
  <div style="font-weight:800">PaintTalk</div>
</header>

<main class="container">
  <h2>رفع رسمة</h2>
  <form method="post" enctype="multipart/form-data">
    <label>العنوان</label>
    <input type="text" name="title" placeholder="عنوان الرسم (اختياري)">

    <label>الوصف (اختياري)</label>
    <textarea name="desc" placeholder="اكتبي وصفاً قصيراً (اختياري)"></textarea>

    <label>الصورة</label>
    <input type="file" name="image" accept="image/*" required>

    <button class="btn submit" type="submit">رفع</button>
    <?php if($msg): ?><div class="msg"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
  </form>
</main>
</body>
</html>