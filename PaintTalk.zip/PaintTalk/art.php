<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit;
}

$id = $_GET['id'] ?? null;
if (!$id) { echo "الرسم غير موجود"; exit; }

// جلب تفاصيل الرسم
$stmt = $pdo->prepare("SELECT * FROM artworks WHERE id = ?");
$stmt->execute([$id]);
$art = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$art) { echo "الرسم غير موجود"; exit; }

// عدد اللايكات وهل المستخدم لاعب لايك
$likeCountStmt = $pdo->prepare("SELECT COUNT(*) FROM likes WHERE artwork_id = ?");
$likeCountStmt->execute([$id]);
$likeCount = (int)$likeCountStmt->fetchColumn();

$userLikedStmt = $pdo->prepare("SELECT 1 FROM likes WHERE user_id = ? AND artwork_id = ?");
$userLikedStmt->execute([$_SESSION['user']['id'], $id]);
$userLiked = (bool)$userLikedStmt->fetchColumn();

// جلب التعليقات
$commentsStmt = $pdo->prepare("
  SELECT c.*, u.username
  FROM art_comments c
  JOIN users u ON u.id = c.user_id
  WHERE c.artwork_id = ?
  ORDER BY c.created_at DESC
");
$commentsStmt->execute([$id]);
$comments = $commentsStmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<title><?= htmlspecialchars($art['title']) ?> | PaintTalk</title>
<style>
:root {
  --bg:#F7F3ED;         /* أوف وايت */
  --card:#ffffff;
  --brand:#7B1E3A;      /* عنّابي */
  --brand-d:#5f152d;
  --muted:#888;
}
*{box-sizing:border-box}
body{
  background:var(--bg);
  font-family:"Tajawal",system-ui,Segoe UI,Arial;
  margin:0; padding:24px;
  color:#222; text-align:center;
}
.container{max-width:850px;margin:0 auto}
h1,h2,h3{margin:10px 0}

.art-box{
  background:var(--card);
  border-radius:18px;
  padding:18px;
  box-shadow:0 8px 24px rgba(0,0,0,0.08);
}
.art-img{
  max-width:100%;
  border-radius:16px;
  box-shadow:0 4px 12px rgba(0,0,0,0.1);
}
.like-row{
  margin-top:14px;
  display:inline-flex; align-items:center; gap:8px;
  background:#fff; padding:8px 14px; border-radius:22px;
  box-shadow:0 2px 6px rgba(0,0,0,0.08);
}
.like-row .count{font-weight:700}
.like-btn{
  border:none; background:none; cursor:pointer;
  font-size:22px; line-height:1; padding:0 2px;
  color: <?= $userLiked ? "'red'" : "'#aaa'" ?>;
  transition:transform .15s ease;
}
.like-btn:hover{ transform:scale(1.15) }

/* التعليقات */
.comments{
  margin-top:22px; text-align:right;
}
.comments h3{
  margin-bottom:10px; color:#333;
}
.comment{
  background:#fff; border-radius:12px; padding:12px 14px; margin-bottom:10px;
  box-shadow:0 2px 8px rgba(0,0,0,0.06);
}
.comment .meta{
  font-size:13px; color:var(--muted); margin-bottom:6px;
}
.comment-form{
  margin-top:14px; display:flex; gap:8px; align-items:flex-start;
}
.comment-form textarea{
  flex:1; min-height:70px; resize:vertical;
  padding:10px 12px; border:1px solid #e6e2dc; border-radius:10px;
  background:#faf7f2; outline:none;
}
.comment-form button{
  border:none; padding:10px 16px; border-radius:10px;
  background:var(--brand); color:#fff; cursor:pointer; font-weight:600;
}
.comment-form button:hover{ background:var(--brand-d); }

/* زر المعرض داخل صفحة الرسمة (عنّابي صغير) */
.topbar{
  display:flex; justify-content:space-between; align-items:center;
  margin-bottom:14px;
}
.topbar a.btn{
  text-decoration:none; background:var(--brand); color:#fff;
  padding:8px 12px; border-radius:10px; font-weight:600;
}
.topbar a.btn:hover{ background:var(--brand-d); }
</style>
</head>
<body>
<div class="container">

  <div class="topbar">
    <a class="btn" href="index.php">المعرض</a>
    <div></div>
  </div>

  <div class="art-box">
    <h2><?= htmlspecialchars($art['title']) ?></h2>
    <?php if(!empty($art['image_path'])): ?>
      <img class="art-img" src="<?= htmlspecialchars($art['image_path']) ?>" alt="">
    <?php endif; ?>
    <?php if(!empty($art['description'])): ?>
      <p><?= nl2br(htmlspecialchars($art['description'])) ?></p>
    <?php endif; ?>

    <!-- لايك -->
    <form method="POST" action="like_toggle.php" class="like-row">
      <button type="submit" class="like-btn" title="أعجبني">
        <?= $userLiked ? "❤️" : "🤍" ?>
      </button>
      <span class="count"><?= $likeCount ?></span>
      <input type="hidden" name="art_id" value="<?= (int)$id ?>">
    </form>
<div class="actions">
    <div class="like-area">
        <?= $like_button ?? '' ?>
    </div>

    <a href="delete_art.php?id=<?= $art['id'] ?>"
       onclick="return confirm('متأكد من حذف الرسمة');"
       class="delete-btn"
       style="
           background:#8b1538;
           color:#ffffff;
           padding:8px 18px;
           border-radius:20px;
           text-decoration:none;
           font-size:15px;
           border:none;
           cursor:pointer;
           display:inline-block;
           margin-top:5px;
       ">
        حذف
    </a>
</div>


    <!-- التعليقات -->
    <div class="comments">
      <h3>التعليقات</h3>

      <!-- نموذج إضافة تعليق -->
      <form class="comment-form" method="POST" action="comment_add.php">
        <textarea name="content" placeholder="اكتبي تعليقك..." maxlength="500" required></textarea>
        <input type="hidden" name="art_id" value="<?= (int)$id ?>">
        <button type="submit">إرسال</button>
      </form>

      <!-- قائمة التعليقات -->
      <?php if ($comments): ?>
        <?php foreach ($comments as $c): ?>
          <div class="comment">
            <div class="meta">
              <strong><?= htmlspecialchars($c['username']) ?></strong>
              · <span><?= htmlspecialchars($c['created_at']) ?></span>
            </div>
            <div class="body"><?= nl2br(htmlspecialchars($c['content'])) ?></div>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <p style="color:var(--muted)">لا توجد تعليقات بعد.</p>
      <?php endif; ?>
    </div>
  </div>

</div>
</body>
</html>ِ